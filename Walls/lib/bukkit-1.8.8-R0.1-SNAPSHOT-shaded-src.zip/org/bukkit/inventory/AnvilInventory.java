package org.bukkit.inventory;

/**
 * Interface to the inventory of an Anvil.
 */
public interface AnvilInventory extends Inventory {
}
