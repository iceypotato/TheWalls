package org.bukkit.inventory;

public enum EquipmentSlot {

    HAND,
    FEET,
    LEGS,
    CHEST,
    HEAD
}
