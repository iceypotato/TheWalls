package org.bukkit.entity;

/**
 * Represents a Chicken.
 */
public interface Chicken extends Animals {}
