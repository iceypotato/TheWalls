package org.bukkit.entity;

/**
 * Represents a Spider.
 */
public interface CaveSpider extends Spider {}
