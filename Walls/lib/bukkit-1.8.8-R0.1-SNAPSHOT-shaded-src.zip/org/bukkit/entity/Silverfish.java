package org.bukkit.entity;

/**
 * Represents a Silverfish.
 */
public interface Silverfish extends Monster {}
